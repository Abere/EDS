<?php
include ('../includes/header.php');
include "connect.php";
//echo "<div id='main'>";
if (isset($_GET['did'])) {
$devID=$_GET['did'];
$query="select * from developer";
$result = $db->query($query);

$num_resulst=$result->num_rows;
for($x=0;$x<=$num_resulst;$x++){
	$row=$result->fetch_assoc();
}

//$num_results = $result->num_rows;
$pic=$row["ProfilePic"];
$nam_first=$row["FirstName"];
$name_last=$row["LastName"];
$gender=$row["Gender"];
$email=$row["Email"];
$date=$row["DateBirth"];
$stat=$row["status"];
echo "<img class='pro1' src='".$pic."'>";
echo "<p>".$nam_first." ".$name_last."</P>";
if ($stat=="prof") {
$queryp="select * from professoinal_developer where id like '%".$devID."%'";
$result = $db->query($queryp);
$row=$result->fetch_assoc();
$cv=$row["CV"];
$org=$row["organization"];
$bio=$row["biography"];
echo "<p>work at: ".$org."</P>";
echo "<p> biography:".$bio."</P>";
echo "<p>cv: ".$cv."</p>";
}
else{
$querya="select * from amatuer_developer where id like '%".$devID."%'";
$result = $db->query($querya);
$row=$result->fetch_assoc();
$orgn=$row["organization"];
echo "<p>work at : ".$orgn."</P>";
}
echo "<p>E-mail: ".$email."</P>";
echo "<p>Gender: ".$gender."</P>";
echo "<p>Birthday: ".$date."</P>";
echo "<p>Curent City: Addis Ababa</P>";
echo "<p>Home Town: Ethiopia</P>";
//echo "<p>Social link: facebook.com//".$nam_first."</P>";
}
include ('../includes/footer.php');

echo "</div>";
?>
<style>
.pro1{
height: 200px;
width: 200px;


}



</style>

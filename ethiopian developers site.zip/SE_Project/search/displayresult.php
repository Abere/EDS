<script >
	function findOnChat(nfid){
	    $.post("../includes/chatfuns.php",{findOnChat:nfid});
	    //alert("hello");
		//$("#priv_chat").load("includes/chatfuns.php");	
	}
</script>
<?php
include ('../includes/header.php');
include 'connect.php';
$count=0;
if (isset($_POST['search_name'])){
$search_name=$_POST['search_name'];
+
$query = "select * from developer where firstName='".$search_name."'" ;
//$query = "select * from developer where firstName=".$search_name.'";
$result = $db->query($query);
$num_results = $result->num_rows;
echo "<div id=''>";
echo "<div id='devpart'>";
echo "<p class='title'>Search results</P>";
if ($num_results>0){
	$count+=$num_results;
echo "<p class='res'>".$num_results."Developers found </p>";}
for($i=0;$i<$num_results;$i++){
$row=$result->fetch_assoc();
$pic=$row["ProfilePic"];
$nam_first=$row["FirstName"];
$name_last=$row["LastName"];
$devId=$row["DEVID"];
echo "<img class='pro1' src='".$pic."'>";
echo "<a  class='prof' href='developerprofile.php? did=".$devId."'><p>".$nam_first." ".$name_last."</p></a>";
echo "<div id='edit'>  
<button onclick=\"findOnChat($devId)\" >find on chat</button> </div>";
}


	

echo "<div id='comp'>";

$qyr="select * from company where Name like '%".$search_name."%'";
$result = $db->query($qyr);
$num_results = $result->num_rows;
if ($num_results>0){
	$count+=$num_results;
echo "<p class='res'>".$num_results."companies found </p>";}
for($i=0;$i<$num_results;$i++){
$row=$result->fetch_assoc();
$pic=$row["logo"];
$nam_first=$row["Name"];
$comp=$row["compID"];
//$name_last=$row["LastName"];
echo "<img class='pro1' src='".$pic."'>";
echo "<a  class='prof' href='companyprofile.php? cid=".$comp."'><p>".$nam_first."</p></a>";

}
echo "</div>";
//$num_results = $result->num_rows;
//echo "<p>Number of rows found: ".$num_results."</p>";
echo "<div id='proje'>";
$qyri="select * from projects_and_demos where Title like '%".$search_name."%'";
$result = $db->query($qyri);
$num_results = $result->num_rows;
if ($num_results>0){
	$count+=$num_results;
echo "<p class='res'>".$num_results."projects found </p>";}
for($i=0;$i<$num_results;$i++){
$row=$result->fetch_assoc();
//$pic=$row["logo"];
$nam_first=$row["Title"];
$desc=$row["Description"];
//$name_last=$row["LastName"];
//echo "<img class='pro1' src='".$pic."'>";
$proid=$row["ID"];
echo "<a  class='prof' href='profile.php? did=".$proid."'><p>".$nam_first."</p></a>";
echo "<p>".$desc."</p>";
}
echo "</div>";
if ($count==0){
	echo "no result found for ".$search_name." search";
}

}

echo "</div>";
//include "../includes/functions.php";
?>
<html>
<head>
	<title></title>
<style>
#devpart{
background-color: rgb(230,230,230);
height: 500px;
width:300px;

}
.title{
position: relative;
left:100px;
top:20px;
font-size: 30px;


}
.pro1{
width: 70px;
height: 70px;


}
.edit{
width: auto;
height: auto;
color:blue;



}








.compart{
background-color: rgb(168,168,168);
position: relative;
left:300px;
top:0px;
width:300px;
height: 500px;

}
.res{
color:red;
font-family: sans-serif;
font-size: 16px;

}
.prof{
text-decoration: none;
color:orange;


}

</style>
</head>
<body>
<?php include ('../includes/footer.php');?>s
</body>

</html>

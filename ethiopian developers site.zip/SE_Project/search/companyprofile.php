<?php
include "connect.php";
include "../includes/header.php";
if (isset($_GET['cid'])) {
$compid=$_GET['cid'];
$query="select * from company where compID like '%".$compid."%'";
$result = $db->query($query);
$row=$result->fetch_assoc();

//$num_results = $result->num_rows;
$pic=$row["logo"];
$nam_first=$row["Name"];
$email=$row["Email"];
$web=$row["Website"];
echo "<img class='pro1' src='".$pic."'>";
echo "<p>".$nam_first."</P>";
echo "<p> E-mail: ".$email."</P>";
echo "<p> website: ".$web."</P>";
include "../includes/footer.php";


}




?>
<style>
.pro1{
height: 200px;
width: 200px;


}



</style>

<?php
include('../Login/connect.php');
include ('../Login/connect3.php');
$u=$membersite->getUserName();
$p=$membersite->getPassword();
$qry ="Select id from login where username='".$u."'and password='".$p."'";    
 $result = $db->query($qry);
        $row1 =$result->fetch_assoc();;
        $id = $row1['id'];

$query="select * from company";
$result = $db->query($query);
$num_resulst=$result->num_rows;
for($x=0;$x<=$num_resulst;$x++){
	$row=$result->fetch_assoc();
}
//$num_results = $result->num_rows;
$pic=$row["logo"];
$nam_first=$row["Name"];
$email=$row["Email"];
$web=$row["Website"];
 include('../includes/header.php');
?>
 
<head>
	<meta charset="utf-8" />
	<title>Social User Profile Page in HTML5/CSS3[DEMO]</title>
	<link rel="stylesheet" type="text/css" href="../css/global.css" />
	<link rel="stylesheet" href="../css/cmpprofile.css">
</head>

<body>	
	 
	
	<div id="content" class="clearfix">
		<section id="left">
			<div id="userStats" class="clearfix">
				<div class="pic">
					<a href="#"><img src="../images/haromaya.jpg" width="150" height="150" alt="Company Logo" /></a>
<!-- 					<br/><br><h3><caption><a>  </a></caption></h3>
 -->				</div>
				
				<div class="data">
					<h1><?php echo $nam_first;?></h1>
					<h3>Addis Ababa, Ethiopia</h3>
					<h4><a href="http://spyrestudios.com/"><?php echo "$web";?></a></h4>
					<div class="socialMediaLinks">
						<a href="http://twitter.com/jakerocheleau" rel="me" target="_blank">Blog</a>
						<a href="http://gowalla.com/users/JakeRocheleau" rel="me" target="_blank">Companies</a>
					</div>
					<div class="sep"></div>
					<ul class="numbers clearfix">
						<li>Connections<strong>185</strong></li>
						<li>Rating<strong>344</strong></li>
						<li class="nobrdr">Blogs<strong>127</strong></li>
					</ul>
				</div>
			</div>
			<div id="about">
			<h1>Company Description:</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumum.</p></div>
		</section>
		
		<section id="right">
			<div class="gcontent">
				<div class="head"><h1>Upload Advertisments</h1></div>
				<div class="boxy">
					<p>Advertisment form to be put here!</p>
					
					 
					
					 
				</div>
			</div>
			
			<div class="gcontent">
				<div class="head"><h1><input id="find_on_chat"type="button" name="findonchat" value="Find on Chat"></input></h1></div>
				<div class="boxy">
					<p>Your friends - 106 total</p>
					
					<div class="friendslist clearfix">
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Abere End." /></a><span class="friendly"><a href="#">Abere E.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Nebyou D." /></a><span class="friendly"><a href="#">Nebyou D.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Beytula K." /></a><span class="friendly"><a href="#">Beytula k..</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Chala G." /></a><span class="friendly"><a href="#">Chala G.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Tsegaye Z." /></a><span class="friendly"><a href="#">Tsegaye z.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Solomon S." /></a><span class="friendly"><a href="#">Solomon S.</a></span>
						</div>
					</div>
					
					 
				</div>
			</div>
		</section>
	</div>
</body>
</html>
<?php include('../includes/cmpprofile_footer.php');?>
<?php
	header("location:welcome.php?page=1");
?>

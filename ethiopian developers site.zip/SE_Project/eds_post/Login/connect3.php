<?PHP
require_once("membersite.php");

$membersite = new Membersite();


$membersite->InitDB('localhost','root','','eds','login');

$membersite->SetRandomKey('qSRcVS6DrTzrPvr');

?>




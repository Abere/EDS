<?PHP
//require_once("class.phpmailer.php");
require_once("../../includes/formvalidator.php");
class Membersite
{

var $admin_email;
    var $from_address;
    //var $id;
    var $username;
    var $pwd;
    var $database;
    var $tablename;
    var $connection;
    var $rand_key;
    
    var $error_message;

function Membersite()
    {
        $this->sitename = 'YourWebsiteName.com';
        $this->rand_key = '0iQx5oBk66oVZep';
    }
   function SetRandomKey($key)
    {
        $this->rand_key = $key;
    } 
function InitDB($host,$uname,$pwd,$database,$tablename)
    {
        $this->db_host  = $host;
        $this->username = $uname;
        $this->pwd  = $pwd;
        $this->database  = $database;
        $this->tablename = $tablename;
        
    }

function GetErrorMessage()
    {
        if(empty($this->error_message))
        {
            return '';
        }
        $errormsg = nl2br(htmlentities($this->error_message));
        return $errormsg;
    }  

    


function GetSelfScript()
    {
        return htmlentities($_SERVER['PHP_SELF']);
    }    
    
function SafeDisplay($value_name)
    {
        if(empty($_POST[$value_name]))
        {
            return'';
        }
        return htmlentities($_POST[$value_name]);
    }
    
function RedirectToURL($url)
    {
        header("Location: $url");
        exit;
    }
function SanitizeForSQL($str)
    {
        if( function_exists( "mysqli_real_escape_string" ) )
        {
              $ret_str = mysqli_real_escape_string($this->connection,$str );
        }
        else
        {
              $ret_str = addslashes( $str );
        }
        return $ret_str;
    }
function HandleError($err)
    {
        $this->error_message .= $err."\r\n";
    }
function LogOut()
    {
        session_start();
        
        $sessionvar = $this->GetLoginSessionVar();
        
        $_SESSION[$sessionvar]=NULL;
        
        unset($_SESSION[$sessionvar]);
    }
 function Login()
    {   
        $fromArticle = -1;

    /*if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //$myusername = mysqli_real_escape_string($db, $_POST['username']);
        //$mypassword = md5(mysqli_real_escape_string($db, $_POST['password']));
        //$sql = "SELECT id FROM login WHERE username = '$myusername' and password = '$mypassword'";  
        //$result = mysqli_query($db, $sql);
        //$count = mysqli_num_rows($result);
        //$error="";

        if ($count == 1) {
            $_SESSION['login_user'] = $myusername;
            $fromArticle = $_GET['postId'];
            if ($fromArticle) {
                header("location: article.php?postId=" . $fromArticle);
            }
            else if ($_GET['newPost']) {
                header("location: createPost.php");
            }
            else {
                header("location: welcome.php?page=1");
            }
        }
        else {
            //$error += "Your Login Name or Password is invalid";
        }
    }*/


    	$username = trim($_POST['username']);
        $password = trim($_POST['password']);
        
        if(empty($_POST['username']))
        {
            $this->HandleError("UserName is empty!");
            return false;
        }
        if ((strlen($password))<6){

        	$this->HandleError("password should be greater than 6!");
            return false;


        }
        if(empty($_POST['password']))
        {
            $this->HandleError("Password is empty!");
            return false;
        }
        
     
        if(!isset($_SESSION)){ session_start(); }
        if(!$this->CheckLoginInDB($username,$password))
        {
            return false;
        }
        
        $_SESSION[$this->GetLoginSessionVar()] = $username;
        
        return true;
    }
    
function GetLoginSessionVar()
    {
        $retvar = md5($this->rand_key);
        $retvar = 'usr_'.substr($retvar,0,10);
        return $retvar;
    }
function CheckLoginInDB($username,$password)
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        }          
        $username = $this->SanitizeForSQL($username);
        $pwdmd5 = md5($password);
        $qry ="Select id from login where username='".$username."'and password='".$pwdmd5."'";
       $result = mysqli_query($this->connection,$qry);
        
        if(!$result || mysqli_num_rows($result) <= 0)
        {
            $this->HandleError("Error logging in. The username or password does not match");
            return false;
        }
        else{
            $_SESSION['login_user'] = $username;
            /*$fromArticle = $_GET['postId'];
            if ($fromArticle) {
                $this->header("location: ../article.php?postId=" . $fromArticle);
            }
            else if ($_GET['newPost']) {
                $this->header("location: ../createPost.php");
            }
            else {
                $this->header("location: ../welcome.php?page=1");
            }*/

        }
        $row = mysqli_fetch_assoc($result);
        
        
        $this->id = $row['id'];
        // $_SESSION['username_of_user'] = $row['username'];
        
        return true;
    }

    function getId()
    {
        if(!$this->DBLogin())
        {
            $this->HandleError("Database login failed!");
            return false;
        }          
        $username = $this->SanitizeForSQL($this->username);
        $pwdmd5 = md5($this->pwd);
        $qry ="Select id from login where username='".$username."'and password='".$pwdmd5."'";
       $result = mysqli_query($this->connection,$qry);
        
        if(!$result || mysqli_num_rows($result) <= 0)
        {
            $this->HandleError("Error logging in. The username or password does not match");
            return false;
        }
        $row = mysqli_fetch_assoc($result);
        
        
        $id = $row['id'];
        $r='sol';
        // $_SESSION['username_of_user'] = $row['username'];
        return $r;
        
        
        
    }

 function DBLogin()
    {

        $this->connection = mysqli_connect($this->db_host,$this->username,$this->pwd,$this->database);

        if(!$this->connection)
        {   
            $this->HandleDBError("Database Login failed! Please make sure that the DB login credentials provided are correct");
            return false;
        }
        if(!mysqli_select_db($this->connection,$this->database))
        {
            $this->HandleDBError('Failed to select database: '.$this->database.' Please make sure that the database name provided is correct');
            return false;
        }
        if(!mysqli_query($this->connection,"SET NAMES 'UTF8'"))
        {
            $this->HandleDBError('Error setting utf8 encoding');
            return false;
        }

        return true;
    }    
    

























}
<!Doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EDS| Home Page</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link href="../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../js/js-image-slider.js" type="text/javascript"></script>
    <script src="../js/jquery.1.9.0.js"></script>
    <script src="../js/jquery.prmenu.min.js"></script>
    <link type="text/css" rel="stylesheet" href="../css/prmenu.css" />
    <link rel="stylesheet" href="../css/base.css" />
    <link rel="stylesheet" href="../css/style-2.css" />
    <script>
        $(document).ready(function(){
              $('#top-menu').prmenu({
                  "fontsize": "14",
                    "height": "50",
                    "case": "uppercase",
                    "linkbgcolor": "#286090",
                    "linktextcolor": "#ccc",
                    "linktextweight": "400",
                    "linktextfont": "sans-serif",
                    "hoverdark": true
                });
        });
    </script>
    <style>body {margin: 0;padding: 0;}</style></head>
<body>
<?php 
include "connect3.php";
$h=$membersite->getId();
echo "the Id:".$h;
include "../includes/chathead.php";
?>
<div id="main">
    
        
        <div id="navigation-bar" class="clearfix">
            
            <form id="search" action="#" method="post">
                <div id="label"><label for="search-terms" id="search-label">search</label></div>
                <div id="input"><input type="text" name="search-terms" id="search-terms" placeholder="Enter search terms..."></div>
            </form>

            <nav>
                <ul>
                    <li><a href="#">EThiopian Developers Site</a></li>
                     
                </ul>
            </nav>

        </div>

</div><!-- #main -->
<div id="container">

    <ul id="top-menu">
        <li><a href="../index.php">Home</a></li>
         <li><a href="">Services</a>
            <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul>
        </li>
            <!-- <li><a href="#">Shop</a>
                <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul> -->
            </li>
            <li><a href="../index.php">Blog</a>
                <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul>
            </li>
            <li><a href="#">Opportunity Portal</a>
                <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul>
            </li>
            <li><a href="">Chat Room</a></li>
            <li><a href="logout.php">Log Out</a>
             
        </li>
    </ul>


 </li>
 </ul>
 </li>
 </ul>
 </div> 
<!--<div id="sidebars">
    <div id="eds"><h3>Ethiopian Developers Site | Search Form</h3></div>-->
 
    <div id="sliderFrame">
        <div id="slider">
            <a href="http://www.menucool.com/">
                <img src="../images/image-slider-1.jpg" alt="Welcome to Menucool.com" />
            </a>
            <a class="lazyImage" href="../images/image-slider-2.jpg" title="Customizable Transition Effects">Customizable Transition Effects</a>
            <a href="http://www.menucool.com/javascript-image-slider">
                <b data-src="../images/image-slider-3.jpg" data-alt="#htmlcaption3">Image Slider</b>
            </a>
            <a class="lazyImage" href="../images/image-slider-4.jpg" title="Pure Javascript. No jQuery. No flash.">Plain Javascript Slider</a>
            <a class="lazyImage" href="../images/image-slider-5.jpg" title="#htmlcaption5">Lazy Loading Image</a>
            <a class="lazyImage" href="../images/image-slider-1.jpg" title="Light weight Image Slider">Light weight Image Slider</a>
            <a class="lazyImage" href="../images/image-slider-2.jpg" title="Fine tuned. Sleek & Smooth">Fine tuned. Sleek & Smooth</a>
            <a class="lazyImage" href="../images/image-slider-3.jpg" title="Easy-to-Use Slider">Easy-to-Use Slider</a>
        </div>
        <div style="display: none;">
            <div id="htmlcaption3">
                <em>HTML</em> caption. Back to <a href="http://www.menucool.com/">Menucool</a>.
            </div>
            <div id="htmlcaption5">
                Smart Lazy Loading Image
            </div>
        </div>
                
        <!--thumbnails-->
        <div id="thumbs">
            <div class="thumb"><img src="../images/thumb1.jpg" /></div>
            <div class="thumb"><img src="../images/thumb2.jpg" /></div>
            <div class="thumb"><img src="../images/thumb3.jpg" /></div>
            <div class="thumb"><img src="../images/thumb4.jpg" /></div>
            <div class="thumb"><img src="../images/thumb5.jpg" /></div>
            <div class="thumb"><img src="../images/thumb1.jpg" /></div>
            <div class="thumb"><img src="../images/thumb2.jpg" /></div>
            <div class="thumb"><img src="../images/thumb3.jpg" /></div>
            <div class="thumb"><img src="../images/thumb1.jpg" /></div>
            <div class="thumb"><img src="../images/thumb2.jpg" /></div>
            <div class="thumb"><img src="../images/thumb3.jpg" /></div>
            <div class="thumb"><img src="../images/thumb4.jpg" /></div>
            <div class="thumb"><img src="../images/thumb5.jpg" /></div>
            <div class="thumb"><img src="../images/thumb1.jpg" /></div>
            <div class="thumb"><img src="../images/thumb2.jpg" /></div>
            <div class="thumb"><img src="../images/thumb3.jpg" /></div>
             
        </div>
    </div>
     </div><div id="mnshea">
<div id="sliderFrame-2"></div>
        <div id="slider-2">
        </div>
        </div>

    <footer id="contact-container">
    <div class="container">
        <a href="" class="white primary btn is-big">
            <span>Contact Us</span><span>To Learn More</span>       </a>
    </div>
</footer>
</main>
</div>

<footer class="global-site-footer">
    <div class="global-site-footer-container">
        <div class="global-site-footer-row">
            <div>
                <a class="selected" href="">
                    <h3>EDS</h3>
                    <span>Browse our products, company,<br> resources, and pricing</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Dashboard</h3>
                    <span>Content, players, analytics,<br> and account management</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Developer</h3>
                    <span>Join the community, demos,<br> references, dev guides, and tools.</span>
                </a>
            </div>
            <div>
                <a href="https://support.jwplayer.com/" target="_blank">
                    <h3>Support</h3>
                    <span>Search the articles, ask the<br> community, or give feedback</span>
                </a>
            </div>
        
        <div class="global-site-footer-row">
            <p>© 2016 Longtail Ad Solutions, Inc. All Rights Reserved.<br> EDS site is a registered social Network.</p>
            </div>
            </div></div>
    
</footer> 

<script src="../js/classie.js"></script>
<script src="../js/search.js"></script>
</body>
</html>
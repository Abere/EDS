<html lang="en">
<head>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>EDS| Home Page</title>
    <link rel="stylesheet" type="text/css" href="../../css/style.css">
    <link href="../../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../../js/js-image-slider.js" type="text/javascript"></script>
	<script src="../../js/jquery.1.9.0.js"></script>
	<script src="../../js/jquery.prmenu.min.js"></script>
	<link type="text/css" rel="stylesheet" href="../../css/prmenu.css" />
    <link rel="stylesheet" href="../../css/base.css" />
    <link rel="stylesheet" href="../../css/style-2.css" />
    <script src="../../js/classie.js"></script>
<script src="../../js/search.js"></script>
	<script>
		$(document).ready(function(){
			  $('#top-menu').prmenu({
				  "fontsize": "14",
					"height": "50",
					"case": "uppercase",
					"linkbgcolor": "#286090",
					"linktextcolor": "#ccc",
					"linktextweight": "400",
					"linktextfont": "sans-serif",
					"hoverdark": true
				});
		});
	</script>
	<style>body {margin: 0;padding: 0;}</style></head>
<body>
    <footer id="contact-container">
    <div class="container">
        <a href="" class="white primary btn is-big">
            <span>Contact Us</span><span>To Learn More</span>       </a>
    </div>
</footer>
 

<footer class="global-site-footer">
    <div class="global-site-footer-container">
        <div class="global-site-footer-row">
            <div>
                <a class="selected" href="">
                    <h3>EDS</h3>
                    <span>Browse our products, company,<br> resources, and pricing</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Dashboard</h3>
                    <span>Content, players, analytics,<br> and account management</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Developer</h3>
                    <span>Join the community, demos,<br> references, dev guides, and tools.</span>
                </a>
            </div>
            <div>
                <a href="https://support.jwplayer.com/" target="_blank">
                    <h3>Support</h3>
                    <span>Search the articles, ask the<br> community, or give feedback</span>
                </a>
            </div>
        
        <div class="global-site-footer-row">
            <p>© 2016 Longtail Ad Solutions, Inc. All Rights Reserved.<br> EDS site is a registered social Network.</p>
            </div>
            </div></div>
    
</footer> 
<script src="../js/classie.js"></script>
<script src="../js/search.js"></script>
</body>
</html>

  <script src="../../js/classie.js"></script>
<script src="../../js/search.js"></script>
 </body>
 </html>
<?php
  //define('DB_SERVER', );
  //define('DB_USERNAME', );
  //define('DB_PASSWORD', );
  //define('DB_DATABASE', );
  $db = mysqli_connect('localhost','root','','eds') or die("Error to connect ") ;
  $articles_per_page = 5;
	
?>

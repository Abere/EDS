<?php
	include('session.php');
   $user_check = $_SESSION['login_user'];
   $ses_sql = mysqli_query($db, "SELECT username from login where username = '$user_check' ");
   $row = mysqli_fetch_array($ses_sql, MYSQLI_ASSOC);
   $login_session = $row['username'];
	$articleId = $_GET['postId'];

	$query = "SELECT * FROM post WHERE id = " . $articleId;
	$retrieval = mysqli_query($db, $query);
	if (! $retrieval) {
		echo 2;
		die('Post not Found.');
	}
	$article = mysqli_fetch_assoc($retrieval);
	if ($_SESSION['login_user'] != $article['author']) {
		echo 3;
		die("Not Authorized.");
	}

	$query = "DELETE FROM post WHERE id = '$articleId'";
	$deletePost = mysqli_query($db, $query);
	if (!$deletePost) {
		echo 4;
		die("Post not Found.");
	}
	$query = "DELETE FROM comment WHERE articleId = '$articleID'";
	$deleteComments = mysqli_query($db, $query);
	echo 1;
?>

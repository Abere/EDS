<?PHP
require_once("member2.php");

$membersite = new Membersite();

$membersite->InitDB('localhost','root','','database','developer');

$membersite->SetRandomKey('qSRcVS6DrTzrPvr');

?>
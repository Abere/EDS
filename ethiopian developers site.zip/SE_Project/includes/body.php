 
<html lang="en">
<head>
	 
	 
    <link rel="stylesheet" type="text/css" href="css/style.css">
     
	 
<body>
      
</div><div id="mnshea">
<div id="sliderFrame-2"><div id="wrapper">
  <div id="mainNav">
    <ul id="homeNav">
      
      <li><a href="#" title="What we think" class="mission">Blogs</a></li>
      <li><a href="#" title="Contact and support" class="contact">Contact</a></li>
      <li><a href="#" title="Explore our tours" class="tours">About</a></li>
      <li><a href="#" title="Guidance and planning" class="resources">Search</a></li>
      <li><a href="#" title="Join our community" class="explorers">Explorers</a></li>
    </ul>
</div>
  <div id="mainContent">
    
    <h1>Current News To be Puted Here</h1>
    <p>At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.
    At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.nce our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.
    At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.nce our beautiful state in a whole new way. Wh thtaking Pacific coastline, we have something for everyone.
    At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new wa e guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone. <em>Come explore.</em></p>
    <!--<div id="spotlight">-->
      <h2>Advertizment Box To be Puted </h2>
      <p>This month's spotlight package is Cycle California. Whether you are looking for some serious downhill thrills to a relaxing ride along the coast, you'll find something to love in Cycle California. <a href="tours_cycle.htm" title="Explore cycling" class="accent">Tour Details</a></p>  
     
    </div>
    
		<section id="articles">

			<article>
				<header>
					<h2>One More Article</h2>
					<p>Posted on March 24th 2013 by <a href="#">Somebody Else</a></p>
				</header>
				<p>Ipsum maecenas tortor nec auctor himenaeos pretium integer a, imperdiet leo nullam dictum dapibus eleifend viverra donec lectus, platea sodales libero phasellus eget hendrerit ipsum posuere feugiat suscipit diam habitasse neque conubia malesuada erat.</p>
			</article>
			

			<article>
				<header>
					<h2>Another Article</h2>
					<p>Posted on March 4th 2013 by <a href="#">Somebody</a> - <a href="#comments">6 comments</a></p>
				</header>
				<p>Etiam nostra feugiat venenatis quis nisi massa ultrices tincidunt blandit, faucibus ultricies at bibendum venenatis condimentum euismod turpis vestibulum, turpis pellentesque risus diam a eros faucibus quisque nunc vel egestas consequat malesuada eros nisl velit interdum sed, aliquam integer inceptos pretium ad vivamus ipsum potenti, hendrerit eleifend etiam fusce ac fringilla urna quisque.</p>
			</article>
			
			<article>
				<header>
					<h2>An Article</h2>
					<p>Posted on February 14th 2013 by <a href="#">A Person</a> - <a href="#comments">3 comments</a></p>
				</header>
				<p>Libero varius neque diam odio tellus purus ultrices porta eget morbi libero sollicitudin, nisi curabitur amet bibendum commodo dictumst venenatis porta quam justo porttitor, habitant fames ut eget sociosqu pretium aenean pharetra suspendisse pharetra malesuada.</p>
			</article>
			
		</section>

		<aside>
			<h2>Featured Highlight</h2>
			<p>Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Massa sagittis luctus aliquet sodales non nisi bibendum eleifend id cursus, donec aliquam habitant dictum tortor habitasse aliquam feugiat rutrum pulvinar platea in semper sollicitudin tempor.</p>
			<p>Etiam nostra feugiat venenatis quis nisi massa ultrices tincidunt blandit, faucibus ultricies at bibendum venenatis condimentum euismod turpis vestibulum, turpis pellentesque risus diam a eros faucibus quisque nunc vel egestas consequat malesuada eros nisl velit interdum sed, aliquam integer inceptos pretium ad vivamus ipsum potenti, hendrerit eleifend etiam fusce ac fringilla urna quisque.</p>
			<p>Ipsum maecenas tortor nec auctor himenaeos pretium integer a, imperdiet leo nullam dictum dapibus eleifend viverra donec lectus, platea sodales libero phasellus eget hendrerit ipsum posuere feugiat suscipit diam habitasse neque conubia malesuada erat.</p>
		</aside>

    </div></div> </div>
</body>
</html>

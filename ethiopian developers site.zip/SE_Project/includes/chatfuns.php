
 


<?php
include "functions.php";
//session_start();
//$_SESSION['friendsId']=$_POST['friendsid'];
            if(isset($_POST['friendsid'])){
                $fid=$_POST['friendsid'];
                
                $_SESSION['friendsId']=$fid;
                
            }
            if($_SESSION['friendsId']>0 && !(is_nan($_SESSION['friendsId']))){
                Messages($_SESSION['userId'],$_SESSION['friendsId']);
            }



            if(isset($_POST['message'])){
				
				$message=$_POST['message'];
        //print_r($_POST['message']);
                sendMessage($_SESSION['friendsId'],$message);
                
            }
           if(isset($_POST['findOnChat'])){
           		//print_r($_POST['findOnChat']);
           		findOnChat($_POST['findOnChat']);
           }



?>


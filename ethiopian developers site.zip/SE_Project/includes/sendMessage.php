
<?php
include "functions.php";

//print_r($_POST);
//session_start();

	$friends=chat_list($_SESSION['userId']);
			?>
			<h3 id="friends_list">Friends List</h3>
			<?php
			for ($i=0; $i < count($friends); $i++){
				$friend=$friends[$i];
			?>
			<p><a onclick="chatfriend(<?php echo $friend->id.",".$_SESSION['userId']; ?>)">
			<?php echo $friend->name;if($friend->unseen>0){ echo "(".$friend->unseen.")";} ?></a></p>
			<?php
			}
			
		/*$sum=0;
			for($i=0;$i<count($friends);$i++){
				$sum+=$friends->unseen;

			}
			return "hi";*/
		

 
            
?>

<?php 
	include "../includes/functions.php";
 ?>
<link rel="stylesheet" type="text/css" href="../css/chat.css">

<div id="chat_drop">
		<div id="chat_room">
		
		<div id="friend_list">
		
	 	
		</div>
		<div id="priv_chat_room">
		<div id="chat_header" >
		
		<button id="back" onclick="hide()" class="btn-1">Back</button>
		</div>
		 
		 <div id="priv_chat">
		 </div>
		 <div id="chat_message_box" > 
		 <form method="POST" onsubmit="return false;">
		<textarea id="chat_message" name="name"></textarea>
		<button class="btn-1" type="submit" id="send_btn">send</button>
		</form>
		</div>
		 
		</div>
	</div>
		
		
	</div>

<button type="button" class="btn-1" id="chat_head">
<?php
//session_start();
//echo $_SESSION['userId'];
?>
chat</button>
<script src="js/chat.js"></script>
<script src="../js/jquery.prmenu.min.js"></script>
<script>
$(document).ready(

	function(){
		loadFriends();
		
		//loadFriends();
		$("#chat_head").click(function(){ 
			hide();
			$("#chat_drop").toggle(1000);
	});	
		setInterval(function(){loadFriends();},2000);


	}
	);
$("#send_btn").click(function(){ 
	var txt=$("#chat_message").val();
    $.post("../includes/chatfuns.php",{message:txt});
    $("#chat_message").val("");
    var element=document.getElementById("priv_chat");
	    element.scrollTop=element.scrollHeight;
 	//$("#chat_header").load("includes/sendMessage.php");
	//alert(txt);	


	});	

	function loadFriends(){
			$("#friend_list").load("../includes/sendMessage.php");
			//$.post("includes/sendMessage.php",{refresh:"true"});
		}
	function findOnChat(nfid){
	    $.post("../includes/chatfuns.php",{findOnChat:nfid});
	    //alert("hello");
		//$("#priv_chat").load("includes/chatfuns.php");	
	}

	
	function chatfriend(fid,uid){
		$.post("../includes/chatfuns.php",{friendsid:fid});
		$("#priv_chat").load("../includes/chatfuns.php");

		setInterval(function(){$("#priv_chat").load("../includes/chatfuns.php");},3000);
		var element=document.getElementById("priv_chat");
	    element.scrollTop=element.scrollHeight;
		view();
	}
	function view(){
	    $("#priv_chat_room").show(500);
	    var element=document.getElementById("priv_chat");
	    element.scrollTop=element.scrollHeight;
	    
	}
	function hide(){
		$("#priv_chat_room").hide(500);

	}	
		        </script>


</body>



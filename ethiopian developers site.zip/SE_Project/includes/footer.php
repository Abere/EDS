<html lang="en">
<head>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>EDS|</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link href="../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../js/js-image-slider.js" type="text/javascript"></script>
	<script src="../js/jquery.1.9.0.js"></script>
	<script src="../js/jquery.prmenu.min.js"></script>
	<link type="text/css" rel="stylesheet" href="../css/prmenu.css" />
    <link rel="stylesheet" href="../css/base.css" />
    <link rel="stylesheet" href="../css/style-2.css" />
    <link rel="stylesheet" href="../css/footer-basic-centered.css">
    <script src="../js/classie.js"></script>
<script src="../js/search.js"></script>
	<script>
		$(document).ready(function(){
			  $('#top-menu').prmenu({
				  "fontsize": "14",
					"height": "50",
					"case": "uppercase",
					"linkbgcolor": "#286090",
					"linktextcolor": "#ccc",
					"linktextweight": "400",
					"linktextfont": "sans-serif",
					"hoverdark": true
				});
		});
	</script>
	<style>body {margin: 0;padding: 0;}</style></head>
<body>
    <footer id="contact-container">
    <div class="containerr">
        <a href="" class="white primary btn is-big">
            <span>Contact Us</span><span>To Learn More</span>       </a>
    </div>
</footer>
 
<footer class="footer-basic-centered">

            <p class="footer-company-motto">Ethiopian Developers Site</p>

            <p class="footer-links">
                <a href="../index.php">Home</a>
                ·
                <a href="../Login/login.php">Blog</a>
                ·
                <a href="#">Demonstrations</a>
                ·
                <a href="#">About</a>
                ·
                <a href="#">Faq</a>
                ·
                <a href="#">Contact</a>
            </p>

            <p class="footer-company-name">Ethiopian Developers Site &copy; 2015</p>

        </footer>
<script src="js/classie.js"></script>
<script src="js/search.js"></script>
</body>
</html>

  <script src="../js/classie.js"></script>
<script src="../js/search.js"></script>
 </body>
 </html>
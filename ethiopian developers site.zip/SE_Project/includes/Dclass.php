<?php
include "Dbconnect.php";
class chat{
	public $chatId;
	public $senderId;
	public $senderName;
    public $receiverId;
    public $message;
    public $status;
    public $date;
}
class friend{
public $id;
public $name;
public $unseen=0;

}




?>


 
<html>

<head>
 
	<title>Footer with a Search Form</title>

	<!--<link rel="stylesheet" href="css/demo.css">-->
	<link rel="stylesheet" href="footer-distributed-with-search.css">

	 

</head>

	<body>

 

		<footer class="footer-distributed">

			<div class="footer-left">

				<p class="footer-links">
					<a href="#">Home</a>
					·
					<a href="#">Blog</a>
					·
					<a href="#">Companies</a>
					·
					<a href="#">About</a>
					·
					<a href="#">Download</a>
					·
					<a href="#">Contact</a>
				</p>

				<p class="footer-company-name">Ethiopian Developers Site &copy; 2015</p>

			</div>

			<div class="footer-right">

				<form method="get" action="#">
					<input placeholder="Enter Search terms..." name="search" />
					<i class="fa fa-search"></i>
				</form>

			</div>

		</footer>

	</body>

</html>

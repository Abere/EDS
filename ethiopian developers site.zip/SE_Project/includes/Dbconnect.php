<?php

define("host", "localhost");
define("user", "root");
define("password", "");
define("db", "eds");


function db_connect(){
	$conn=new mysqli(host,user,password,db);

	if($conn-> connect_error){
		die("unable to connect ".$conn-> connect_error);

	}

	return $conn;

}


?>
<?php
include "Dbconnect.php";
session_start();
class chat{
    public $chatId;
    public $senderId;
    public $senderName;
    public $receiverId;
    public $message;
    public $status;
    public $date;
}
class friend{
public $id;
public $name;
public $unseen=0;

}

 function chat_list($userId){

	$friends=array();
 	
     $con = db_connect();
     $query = "select id,senderid,receiverid,status from chat";
     $queryname = "select  devid,firstname,lastname from developer";
     $stmt = $con->prepare($query);
     $stmtname = $con->prepare($queryname);
     if ($stmt->execute()) {
     	$stmt->store_result();
     	$stmt->bind_result($id ,$senderid,$receiverid,$status);

            while ($stmt->fetch()) {            	

            	if($userId==$senderid){
            		if($stmtname->execute()){  
			            $stmtname->store_result();
			             $stmtname->bind_result($usersid ,$name,$lname);
		            	while ($stmtname->fetch()) {
		            		if($receiverid==$usersid){
		            			$friendnew=new friend(); 		            			           			
		            			$friendnew->id=$usersid;
	            				$friendnew->name=$name." ".$lname;
		            			$flag=true;
		            			for ($i=0; $i <count($friends); $i++){
		            				$friend=$friends[$i];	            				
			            				if ($friend->id==$usersid) {
			            					$flag=false;			
                                                        					
			            					}	            				
		            				}

		            			if($flag){  	            				         		   					
	            					array_push($friends, $friendnew);            					
	            					}		            			
		            			}
		            		} 
	            		}             		
            		}
            	if($userId==$receiverid){  
	            	if($stmtname->execute()){  
			            $stmtname->store_result();
			             $stmtname->bind_result($usersid ,$name,$lname);          		 
		            	while ($stmtname->fetch()) {
		            		if($senderid==$usersid){	            			
		            			$friendnew=new friend(); 
		            			$friendnew->id=$usersid;
	            				$friendnew->name=$name." ".$lname;
	            				$flag=true;	            			
		            			for ($i=0; $i <count($friends); $i++){
		            				$friend=$friends[$i];
			            				if ($friend->id==$usersid) {
			            					$flag=false;
                                            if($status=="delivered"){
                                                    $friends[$i]->unseen+=1;
                                                }		            					
			            					}	            				
		            				}

		            			if($flag ){            		   					
	            					array_push($friends, $friendnew);            					
	            					}	            			
		            			}
		            		}
		            	}            	
            		}            	
            	}
            	return $friends;              
        }
    }

 function Messages($usersid,$friendsid){

      $chatdetail=new chat();
      $currentchat=array();
 	 $con = db_connect();
     $query = "select * from chat";
     //$queryname = "select  devid,firstname,lastname from developer";
     $stmt = $con->prepare($query);
     if($stmt-> execute()){
     		$stmt->store_result();
     		$stmt->bind_result($id,$senderid,$sendername,$receiverid,$message,$status,$date);
     		while ($stmt->fetch()) {
     			if(($senderid==$usersid and $receiverid==$friendsid)){
                    if($status=="request"){
                    echo"<p id=\"request\">you started conversation with ".$message.".</p>";

                    }else{
     				echo"<p id=\"sent_message\">you:<br>";
     				echo $message."<br><span id=\"status\">--".$status."--</span></p>";
                    }
     			}else if(($senderid==$friendsid and $receiverid==$usersid)){
                    if($status=="delivered"){
                    $update=$con->prepare("UPDATE chat SET status=\"seen\" WHERE id=$id");
                    //$update->bind_param("i",$);
                    $update->execute();
                    $update->close();
                    }
                    if($status=="request"){
                    echo"<p id=\"request\">".$sendername." started conversation with you."."</p>";

                    }else{
                    echo"<p id=\"recieved_message\" >".$sendername.":<br>";
                    echo $message."</p>";
                    }

                }

     			# code...
     		}
     		//return $currentchat;

     }


 }

function sendMessage($friendsid,$message){
	 
     $con=db_connect();  
     $username=$_SESSION["userName"];
     $usersid=$_SESSION["userId"];
     $status="delivered";
     print_r($friendsid);
     print_r($message);
     	$stmt3=$con->prepare("INSERT INTO chat (senderId, senderName, receiverid, message, status) VALUES (?, ?, ?, ?, ?)");
			$stmt3->bind_param("isiss", $usersid, $username, $friendsid, $message, $status);
			$stmt3->execute();
			$stmt3->close();
			$con->close();
            echo "done";
}
function findOnChat($friendsid){
     $con=db_connect();  
     $username=$_SESSION["userName"];
     $usersid=$_SESSION["userId"];
     $status="request";
     $queryname = "select  devid,firstname from developer";
     $stmt= $con->prepare($queryname);
     if ($stmt->execute()) {
        $stmt->store_result();
        $stmt->bind_result($id ,$name);
        while ($stmt->fetch()) {
            if($friendsid==$id){
                $message=$name;
            }
        }
    }
     
        $stmt3=$con->prepare("INSERT INTO chat (senderId, senderName, receiverid, message, status) VALUES (?, ?, ?, ?, ?)");
            $stmt3->bind_param("isiss", $usersid, $username, $friendsid, $message, $status);
            $stmt3->execute();
            $stmt3->close();
            $con->close();
            echo "done";

}
            		

?>
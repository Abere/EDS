<html lang="en">
<head>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>EDS| Home Page</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link href="../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../js/js-image-slider.js" type="text/javascript"></script>
	<script src="../js/jquery.1.9.0.js"></script>
	<script src="../js/jquery.prmenu.min.js"></script>
	<link type="text/css" rel="stylesheet" href="../css/prmenu.css" />
    <link rel="stylesheet" href="../css/base.css" />
    <link rel="stylesheet" href="../css/style-2.css" />
     
	<script>
		$(document).ready(function(){
			  $('#top-menu').prmenu({
				  "fontsize": "14",
					"height": "50",
					"case": "uppercase",
					"linkbgcolor": "#286090",
					"linktextcolor": "#ccc",
					"linktextweight": "400",
					"linktextfont": "sans-serif",
					"hoverdark": true
				});
		});
	</script>
	<style>body {margin: 0;padding: 0;}</style></head>
<body>
<div id="main">
    
        
        <div id="navigation-bar" class="clearfix">
            
           <form id="search" action="../search/displayresult1.php" method="post">
                <div id="label"><label for="search-terms" id="search-label">search</label></div>
                <div id="input"><input type="text" name="search_name" id="search-terms" placeholder="Enter search terms..."></div>
            </form>

            <nav>
                <ul>
                    <li><a href="#">EDS</a></li>
                     
                </ul>
            </nav>

        </div>

</div><!-- #main -->
<div id="container">

	<ul id="top-menu">
        <li><a href="../index.php">Home</a></li>
         <li><a href="">Community</a>
            <ul>
                <li><a href="">Developers</a></li>
                <li><a href="">IT Enterprises</a></li>
                <li><a href="">Technology Companies</a></li>
                <li><a href="">Forum</a></li>
                <li><a href="">Demonstrations</a></li>
            </ul>
        </li>
            <li><a href="#">Events</a>
                <ul>
                <li><a href="">Near by Events</a></li>
                <li><a href="">Past Events</a></li>
                <li><a href="">upcomming Events</a></li>
               
            </ul>
            </li>
            <li><a href="../eds_post/index.php">Blog</a>
                <ul>
                <li><a href="">Opportunities</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Recent Conversations</a></li>
                 
                <li><a href="">Ask Questions</a></li>
                 
            </ul>
            </li>
            <li><a href="#">About</a>
               
            </li>
              <li><a href="#">Edit Profile</a>
            <ul>
            <li><a href="../signup/signupfordeveloper.php">Sign up as developer</a></li>
            <li><a href="../signup/signupforc.php">Sign up as company</a></li>
            
            </ul>
            </li>
            <li><a href="../index.php">Logout</a>
            <ul>
            <li><a href="../Login/logind.php">Developer</a></li>
            <li><a href="../Login/loginc.php">Company</a></li>
            
            </ul>
             
             
        </li>
    </ul>



 </li>
 </ul>
 </li>
 </ul>
 </div> 
 <script src="../js/classie.js"></script>
<script src="../js/search.js"></script>
 </body>
 </html>
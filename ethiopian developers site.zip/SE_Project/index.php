<!Doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EDS| Home Page</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="js/js-image-slider.js" type="text/javascript"></script>
    <script src="js/jquery.1.9.0.js"></script>
    <script src="js/jquery.prmenu.min.js"></script>
    <link type="text/css" rel="stylesheet" href="css/prmenu.css" />
    <link rel="stylesheet" href="css/base.css" />
    <link rel="stylesheet" href="css/style-2.css" />
    <link rel="stylesheet" type="text/css" href="css/body.css" />
    <script>
        $(document).ready(function(){
              $('#top-menu').prmenu({
                  "fontsize": "14",
                    "height": "50",
                    "case": "uppercase",
                    "linkbgcolor": "#286090",
                    "linktextcolor": "#ccc",
                    "linktextweight": "400",
                    "linktextfont": "sans-serif",
                    "hoverdark": true
                });
        });
    </script>
    <style>body {margin: 0;padding: 0;}</style></head>
<body>
<div id="main">
    
        
        <div id="navigation-bar" class="clearfix">
            
             <form id="search" action="search/displayresult.php" method="post">
                <div id="label"><label for="search-terms" id="search-label">search</label></div>
                <div id="input"><input type="text" name="search_name" id="search-terms" placeholder="Enter search terms..."></div>
            </form>

            <nav>
                <ul>
                    <li><a href="#">EDS</a></li>
                     
                </ul>
            </nav>

        </div>

</div><!-- #main -->
<div id="container">

    <ul id="top-menu">
        <li><a href="index.php">Home</a></li>
         <li><a href="">Community</a>
            <ul>
                <li><a href="">Developers</a></li>
                <li><a href="">IT Enterprises</a></li>
                <li><a href="">Technology Companies</a></li>
                <li><a href="">Forum</a></li>
                <li><a href="">Demonstrations</a></li>
            </ul>
        </li>
            <li><a href="#">Events</a>
                <ul>
                <li><a href="">Near by Events</a></li>
                <li><a href="">Past Events</a></li>
                <li><a href="">upcomming Events</a></li>
               
            </ul>
            </li>
            <li><a href="eds_post/Login/login.php">Blog</a>
                <ul>
                <li><a href="">Opportunities</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Recent Conversations</a></li>
                 
                <li><a href="">Ask Questions</a></li>
                 
            </ul>
            </li>
            <li><a href="#">About</a>
                <ul>
                <li><a href="">Ethiopian Developers</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">opportunities</a></li>
                 
            </ul>
            </li>
            <li><a href="#">Register</a>
            <ul>
            <li><a href="signup/signupfordeveloper.php">Sign up as developer</a></li>
            <li><a href="signup/signupforc.php">Sign up as company</a></li>
            
            </ul>
            </li>
            <li><a href="#">Login</a>
            <ul>
            <li><a href="Login/logind.php">Developer</a></li>
            <li><a href="Login/loginc.php">Company</a></li>
            
            </ul>
             
        </li>
    </ul>


 </li>
 </ul>
 </li>
 </ul>
 </div> 
 <!--Slider-->
 
    <div id="sliderFrame">
        <div id="slider">
            <a href="index.php">
                <img src="images/img_7.jpg" alt="Welcome to EDS.com" title="" />
            </a>
            <a class="lazyImage" href="images/img_8.jpg" title="Join Ethiopian Developers Site">Welcome To Ethiopian Developers Site</a>
            <a href="">
                <b data-src="images/img_1.jpg" data-alt="Connect with Inovation Hubs">Connect with Inovation Hubs</b>
            </a>
            <a class="lazyImage" href="images/img_5.jpg" title="Explore Blogs. See what has been written about software technologies">Explore</a>
            <a class="lazyImage" href="images/img_2.jpg" title="Advertize your products">Advertize your products</a>
            <a class="lazyImage" href="images/img_1.jpg" title="Explore recent Technologies">Explore recent Technologies</a>
            <a class="lazyImage" href="images/img_10.jpg" title="Participate in Technology Forums">Participate in Technology Forums</a>
            <a class="lazyImage" href="images/img_11.jpg" title="Join The community To explore the programming world">Join The community To explore the programming world</a>
        </div>
        <div style="display: none;">
            <div id="htmlcaption3">
                <em>Join</em> the <a href="">Eds.com</a>.
            </div>
            <div id="htmlcaption5">
                Find Developers
            </div>
        </div>
                
        <!--thumbnails-->
        <div id="thumbs">
            <div class="thumb"><img src="images/thu1.jpeg" /></div>
            <div class="thumb"><img src="images/thu5.jpg" /></div>
            <div class="thumb"><img src="images/thu3.jpg" /></div>
            <div class="thumb"><img src="images/thu2.jpg" /></div>
            <div class="thumb"><img src="images/thu6.jpg" /></div>
            <div class="thumb"><img src="images/thu4.jpg" /></div>
            <div class="thumb"><img src="images/thu1.jpeg" /></div>
            <div class="thumb"><img src="images/thu5.jpg" /></div>
            <div class="thumb"><img src="images/thu3.jpg" /></div>
            <div class="thumb"><img src="images/thu2.jpg" /></div>
            <div class="thumb"><img src="images/thu6.jpg" /></div>
            <div class="thumb"><img src="images/thu4.jpg" /></div>
            <div class="thumb"><img src="images/thu1.jpeg" /></div>
            <div class="thumb"><img src="images/thu5.jpg" /></div>
            <div class="thumb"><img src="images/thu3.jpg" /></div>
            <div class="thumb"><img src="images/thu2.jpg" /></div>
             
        </div>
    </div>
 </div><div id="mnshea">
<div id="sliderFrame-2"><div id="wrapper">
  <div id="mainNav">
    <ul id="homeNav">
      
      <li><a href="eds_post/Login/login.php" title="What we think" class="mission">Blogs</a></li>
      <li><a href="#" title="Contact and support" class="contact">Contact</a></li>
      <li><a href="#" title="Explore our tours" class="tours">About</a></li>
      <li><a href="eds_post/Login/login.php" title="Guidance and planning" class="resources">Search</a></li>
      <li><a href="#" title="Join our community" class="explorers">Explorers</a></li>
    </ul>
</div>
  <div id="mainContent">
    
    <h1>Current News To be Put Here</h1>
    <p>At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.
    At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.nce our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.
    At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new way. Whether you want to take guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone.nce our beautiful state in a whole new way. Wh thtaking Pacific coastline, we have something for everyone.
    At Explore California, we want you to do just that, explore our wild and wonderful state any way you please. Our tour packages are as diverse as California itself and are designed to let you experience our beautiful state in a whole new wa e guided tours through stunning wine country, or set your own agenda as you bike along miles of breathtaking Pacific coastline, we have something for everyone. <em>Come explore.</em></p>
    <!--<div id="spotlight">-->
      <h2>Events,and Upcoming Forums </h2>
      <p>This month's spotlight package is Cycle California. Whether you are looking for some serious downhill thrills to a relaxing ride along the coast, you'll find something to love in Cycle California. <a href="tours_cycle.htm" title="Explore cycling" class="accent">Tour Details</a></p>  
     
    </div>
    
        <section id="articles">

            <article>
                <header>
                    <h2>One More Article</h2>
                    <p>Posted on March 24th 2013 by <a href="#">Somebody Else</a></p>
                </header>
                <p>Ipsum maecenas tortor nec auctor himenaeos pretium integer a, imperdiet leo nullam dictum dapibus eleifend viverra donec lectus, platea sodales libero phasellus eget hendrerit ipsum posuere feugiat suscipit diam habitasse neque conubia malesuada erat.</p>
            </article>
            

            <article>
                <header>
                    <h2>Another Article</h2>
                    <p>Posted on March 4th 2013 by <a href="#">Somebody</a> - <a href="#comments">6 comments</a></p>
                </header>
                <p>Etiam nostra feugiat venenatis quis nisi massa ultrices tincidunt blandit, faucibus ultricies at bibendum venenatis condimentum euismod turpis vestibulum, turpis pellentesque risus diam a eros faucibus quisque nunc vel egestas consequat malesuada eros nisl velit interdum sed, aliquam integer inceptos pretium ad vivamus ipsum potenti, hendrerit eleifend etiam fusce ac fringilla urna quisque.</p>
            </article>
            
            <article>
                <header>
                    <h2>An Article</h2>
                    <p>Posted on February 14th 2013 by <a href="#">A Person</a> - <a href="#comments">3 comments</a></p>
                </header>
                <p>Libero varius neque diam odio tellus purus ultrices porta eget morbi libero sollicitudin, nisi curabitur amet bibendum commodo dictumst venenatis porta quam justo porttitor, habitant fames ut eget sociosqu pretium aenean pharetra suspendisse pharetra malesuada.</p>
            </article>
            
        </section>

        <aside>
            <h2>New Advertisments</h2>
            <p>Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Massa sagittis luctus aliquet sodales non nisi bibendum eleifend id cursus, donec aliquam habitant dictum tortor habitasse aliquam feugiat rutrum pulvinar platea in semper sollicitudin tempor.</p>
            <p>Etiam nostra feugiat venenatis quis nisi massa ultrices tincidunt blandit, faucibus ultricies at bibendum venenatis condimentum euismod turpis vestibulum, turpis pellentesque risus diam a eros faucibus quisque nunc vel egestas consequat malesuada eros nisl velit interdum sed, aliquam integer inceptos pretium ad vivamus ipsum potenti, hendrerit eleifend etiam fusce ac fringilla urna quisque.</p>
            <p>Ipsum maecenas tortor nec auctor himenaeos pretium integer a, imperdiet leo nullam dictum dapibus eleifend viverra donec lectus, platea sodales libero phasellus eget hendrerit ipsum posuere feugiat suscipit diam habitasse neque conubia malesuada erat.</p>
        </aside>

    </div></div> </div> <div></div>
    


<footer id="contact-container">
<footer class="global-site-footer">
     
    <div class="global-site-footer-container">
        <div class="global-site-footer-row">
            <div>
                <a class="selected" href="">
                    <h3>EDS</h3>
                    <span>Browse our products, company,<br> resources, and pricing</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Dashboard</h3>
                    <span>News, Blogs, demonstrations,<br> and join the community</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Developer</h3>
                    <span>Join the community, demos,<br> references, dev guides, and tools.</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Chat</h3>
                    <span>Talk with fellow, developer,<br> ask references, dev guides, and tools.</span>
                </a>
            </div>
            <div>
                <a href="" target="_blank">
                    <h3>Blogs</h3>
                    <span>Search the articles, ask the<br> community, or give Comments</span>
                </a>
            </div>
        
        <div class="global-site-footer-row">
            <p>© 2016 Ethiopian Developers Site, Inc. All Rights Reserved.<br> EDS site is a to be registered social Network.</p>
            </div>
            </div></div>
    
</footer> 
<script src="js/classie.js"></script>
<script src="js/search.js"></script>
</body>
</html>
 <?php
include('../Login/connect.php');

		
			
			//include ('../includes/functions.php');
			
include('../includes/header1.php');	
include ('../includes/chathead.php'); 
$id=$_SESSION['userId'];
$query="select * from developer where devid='".$id."'";
$result = $db->query($query);
$row=$result->fetch_assoc();
	
//$num_results = $result->num_rows;
$pic=$row["ProfilePic"];
$nam_first=$row["FirstName"];
$name_last=$row["LastName"];
$gender=$row["Gender"];
$email=$row["Email"];
$date=$row["DateBirth"];
$stat=$row["status"];


?>

<head>
	<meta charset="utf-8" />
	<title>Social User Profile Page in HTML5/CSS3[DEMO]</title>
	<link rel="stylesheet" type="text/css" href="../css/global.css" />
	<link rel="stylesheet" href="../css/footer-distributed-with-search.css">
</head>

<body>	
	 
	
	<div id="content" class="clearfix">
		<section id="left">
			<div id="userStats" class="clearfix">
				<div class="pic">
					<a href="#"><img src="../images/user_avatar.jpg" width="150" height="150" /></a>
					<br/><br><h3><caption><a> Edit Profile</a></caption></h3>
				</div>
				
				<div class="data">
					<h1><?php echo $nam_first." ".$name_last; ?></h1>
					<h3>Addis Ababa, Ethiopia</h3>
					<h4><a href="http://spyrestudios.com/">http://spyrestudios.com/</a></h4>
					<div class="socialMediaLinks">
						<a href="../eds_post/index.php" rel="me" target="_blank">Blog</a>
						<a href="http://gowalla.com/users/JakeRocheleau" rel="me" target="_blank">Companies</a>
					</div>
					<div class="sep"></div>
					<ul class="numbers clearfix">
						<li>Connections<strong>185</strong></li>
						<li>Rating<strong>344</strong></li>
				<a href="../eds_post/index.php"><li class="nobrdr">Blogs<strong>127</strong></li></a>


					</ul>
				</div>
			</div>

			<div id="about">
			<h1>About Me:</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumum.</p></div>
		</section>
		
		<section id="right">
			<div class="gcontent">
				<div class="head"><h1>Upload Projects</h1></div>
				<div class="boxy">
					<p>Download form to be put here!</p>
					
					 
					
					 
				</div>
			</div>
			
			<div class="gcontent">
				<div class="head"><h1><input id="find_on_chat"type="button" name="findonchat" value="Find on Chat"></input></h1></div>
				<div class="boxy">
					<p>Your friends - 106 total</p>
					
					<div class="friendslist clearfix">
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Abere End." /></a><span class="friendly"><a href="#">Abere E.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Nebyou D." /></a><span class="friendly"><a href="#">Nebyou D.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Beytula K." /></a><span class="friendly"><a href="#">Beytula k..</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Chala G." /></a><span class="friendly"><a href="#">Chala G.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Tsegaye Z." /></a><span class="friendly"><a href="#">Tsegaye z.</a></span>
						</div>
						
						<div class="friend">
							<a href="#"><img src="../images/friend_avatar_default.jpg" width="30" height="30" alt="Solomon S." /></a><span class="friendly"><a href="#">Solomon S.</a></span>
						</div>
					</div>
					
					 
				</div>
			</div>
		</section>
	</div>
</body>
</html>
<?php include('../includes/devprofile_footer.php');?>
<?PHP
require_once("connect3.php");

$membersite->LogOut();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Login</title>
      <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css" />
      <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
</head>
<body>
<?php include('../includes/header.php')  ?>
<h1>You have successfully Loged Out</h1><h1></h1><h1></h1> 
<h3>Click
<a href='login.php'>Login Again</a> to go back where you left of!
</h3>
<?php include('../includes/footer.php')  ?>
</body>
</html>
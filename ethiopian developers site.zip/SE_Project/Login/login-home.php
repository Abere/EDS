<!Doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EDS| Home Page</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link href="../css/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="../js/js-image-slider.js" type="text/javascript"></script>
    <script src="../js/jquery.1.9.0.js"></script>
    <script src="../js/jquery.prmenu.min.js"></script>
    <link type="text/css" rel="stylesheet" href="../css/prmenu.css" />
    <link rel="stylesheet" href="../css/base.css" />
    <link rel="stylesheet" href="../css/style-2.css" />
    <script>
        $(document).ready(function(){
              $('#top-menu').prmenu({
                  "fontsize": "14",
                    "height": "50",
                    "case": "uppercase",
                    "linkbgcolor": "#286090",
                    "linktextcolor": "#ccc",
                    "linktextweight": "400",
                    "linktextfont": "sans-serif",
                    "hoverdark": true
                });
        });
    </script>
    <style>body {margin: 0;padding: 0;}</style></head>
<body>

<div id="main">
    
        
        <div id="navigation-bar" class="clearfix">
            
            <form id="search" action="#" method="post">
                <div id="label"><label for="search-terms" id="search-label">search</label></div>
                <div id="input"><input type="text" name="search-terms" id="search-terms" placeholder="Enter search terms..."></div>
            </form>

            <nav>
                <ul>
                    <li><a href="#">EThiopian Developers Site</a></li>
                     
                </ul>
            </nav>

        </div>

</div><!-- #main -->

<div id="container">

    <ul id="top-menu">
        <li><a href="../index.php">Home</a></li>
         <li><a href="">Services</a>
            <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul>
        </li>
            <!-- <li><a href="#">Shop</a>
                <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul> -->
            </li>
            <li><a href="bllog.html">Blog</a>
                <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul>
            </li>
            <li><a href="#">Opportunity Portal</a>
                <ul>
                <li><a href="">Personal</a></li>
                <li><a href="">Business</a></li>
                <li><a href="">Professional Services</a></li>
                <li><a href="">Demonstrations</a></li>
                <li><a href="">Answer To Questions</a></li>
                <li><a href="">Supporting Materials</a></li>
            </ul>
            </li>
            <li><a href="">Chat Room</a></li>
            <li><a href="logout.php">Log Out</a>
             
        </li>
    </ul>


 </li>
 </ul>
 </li>
 </ul>
 </div> 
<!--<div id="sidebars">
    <div id="eds"><h3>Ethiopian Developers Site | Search Form</h3></div>-->
 
    <div id="sliderFrame">
        <div id="slider">
            <a href="index.php">
                <img src="../images/img_7.jpg" alt="Welcome to EDS.com" title="" />
            </a>
            <a class="lazyImage" href="../images/img_8.jpg" title="Join Ethiopian Developers Site">Welcome To Ethiopian Developers Site</a>
            <a href="">
                <b data-src="../images/img_1.jpg" data-alt="Connect with Inovation Hubs">Connect with Inovation Hubs</b>
            </a>
            <a class="lazyImage" href="../images/img_5.jpg" title="Explore Blogs. See what has been written about software technologies">Explore</a>
            <a class="lazyImage" href="../images/img_2.jpg" title="Advertize your products">Advertize your products</a>
            <a class="lazyImage" href="../images/img_1.jpg" title="Explore recent Technologies">Explore recent Technologies</a>
            <a class="lazyImage" href="../images/img_10.jpg" title="Participate in Technology Forums">Participate in Technology Forums</a>
            <a class="lazyImage" href="../images/img_11.jpg" title="Join The community To explore the programming world">Join The community To explore the programming world</a>
        </div>
        <div style="display: none;">
            <div id="htmlcaption3">
                <em>Join</em> the <a href="">Eds.com</a>.
            </div>
            <div id="htmlcaption5">
                Find Developers
            </div>
        </div>
                
        <!--thumbnails-->
        <div id="thumbs">
            <div class="thumb"><img src="../images/thu1.jpeg" /></div>
            <div class="thumb"><img src="../images/thu5.jpg" /></div>
            <div class="thumb"><img src="../images/thu3.jpg" /></div>
            <div class="thumb"><img src="../images/thu2.jpg" /></div>
            <div class="thumb"><img src="../images/thu6.jpg" /></div>
            <div class="thumb"><img src="../images/thu4.jpg" /></div>
            <div class="thumb"><img src="../images/thu1.jpeg" /></div>
            <div class="thumb"><img src="../images/thu5.jpg" /></div>
            <div class="thumb"><img src="../images/thu3.jpg" /></div>
            <div class="thumb"><img src="../images/thu2.jpg" /></div>
            <div class="thumb"><img src="../images/thu6.jpg" /></div>
            <div class="thumb"><img src="../images/thu4.jpg" /></div>
            <div class="thumb"><img src="../images/thu1.jpeg" /></div>
            <div class="thumb"><img src="../images/thu5.jpg" /></div>
            <div class="thumb"><img src="../images/thu3.jpg" /></div>
            <div class="thumb"><img src="../images/thu2.jpg" /></div>
             
        </div>
    </div>
     </div><div id="mnshea">
<div id="sliderFrame-2"></div>
        <div id="slider-2">
        </div>
        </div>

    <footer id="contact-container">
    <div class="container">
        <a href="" class="white primary btn is-big">
            <span>Contact Us</span><span>To Learn More</span>       </a>
    </div>
</footer>
</main>
</div>
<?php 

//session_start();

//echo "the Id:".$_SESSION['userName'];
include "../includes/chathead.php";
?>
 
 <?php include('../includes/footer.php');?> 

<script src="../js/classie.js"></script>
<script src="../js/search.js"></script>
</body>
</html>
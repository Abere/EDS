<?php
@ $db = new mysqli('localhost', 'root', '', 'eds');
if (mysqli_connect_errno()) {
echo 'Error: Could not connect to database. Please try again later.';
exit;

}

?>





Group 1
1-Abere Endeshaw
2-Beytula Kedir
3-Chala Getu
4-Firaol Kelbesa
5-Nebeyu Daniel
6-Solomon Shiferaw
7-Tsegaye Zeru




database name -eds
server-localhost
username-root
password-

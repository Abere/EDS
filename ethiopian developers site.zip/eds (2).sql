-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2016 at 05:42 AM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eds`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisment`
--

DROP TABLE IF EXISTS `advertisment`;
CREATE TABLE IF NOT EXISTS `advertisment` (
  `Title` varchar(40) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `desctiption` varchar(500) NOT NULL,
  `image` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertisment`
--

INSERT INTO `advertisment` (`Title`, `startDate`, `endDate`, `desctiption`, `image`) VALUES
('samsungS7', '2016-02-12', '2016-06-16', 'kjas kfcehaenjkewrjewh ', 'image.png'),
('samsungS7', '2016-02-12', '2016-06-16', 'kjas kfcehaenjkewrjewh ', 'image.png'),
('iphone', '2016-02-12', '2016-06-16', 'hajsdkf', 'image.png');

-- --------------------------------------------------------

--
-- Table structure for table `amatuer_developer`
--

DROP TABLE IF EXISTS `amatuer_developer`;
CREATE TABLE IF NOT EXISTS `amatuer_developer` (
  `organization` varchar(30) NOT NULL,
  `id` int(4) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `amatuer_developer`
--

INSERT INTO `amatuer_developer` (`organization`, `id`) VALUES
('jimma', 23),
('AAU', 8563);

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `senderId` int(4) NOT NULL,
  `senderName` text NOT NULL,
  `receiverId` int(4) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(15) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`ID`, `senderId`, `senderName`, `receiverId`, `message`, `status`, `date`) VALUES
(53, 5643, 'Daniel', 5650, 'hi hiwiyee', 'seen', NULL),
(52, 5650, 'hiwot', 5643, 'Daniel', 'request', NULL),
(51, 5650, 'hiwot', 5632, 'abere', 'request', NULL),
(50, 5650, 'hiwot', 5632, 'abere', 'request', NULL),
(49, 1, 'Abebe', 5643, 'sup dude', 'seen', NULL),
(48, 5643, 'Daniel', 1, 'hi abe', 'seen', NULL),
(47, 5643, 'Daniel', 1, 'hiel', 'seen', NULL),
(46, 1, 'abebe', 5643, 'sup', 'seen', NULL),
(45, 1, 'abebe', 5643, 'hay', 'seen', NULL),
(44, 5643, 'Daniel', 1, 'hi', 'seen', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `articleId` int(11) NOT NULL,
  `author` tinytext,
  `content` text,
  `post_time` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `articleId`, `author`, `content`, `post_time`) VALUES
(1, 2, 'chala', 'best post of the year', 'Jun 6, 2016'),
(2, 2, 'chala', 'good post bro ', 'Jun 6, 2016'),
(3, 3, 'nati', 'Properties represent structural features of a class.', 'Jun 7, 2016'),
(4, 3, 'chala', 'Properties represent structural features of a class', 'Jun 7, 2016'),
(5, 3, 'nati', 'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', 'Jun 7, 2016'),
(6, 3, 'chala', 'Properties represent structural features of a class. .', 'Jun 7, 2016'),
(7, 3, 'chala', 'thank yu good to know', 'Jun 17, 2016'),
(8, 4, 'chala', 'microsoft must have a good reason for buying it', 'Jun 17, 2016'),
(9, 4, 'chala', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'Jun 20, 2016'),
(10, 6, 'susi', 'good post though', 'Jun 20, 2016'),
(11, 9, 'susi', 'nnnnnnnnnnnnnnnnnnnnnnnnnnn', 'Jun 20, 2016');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `compID` int(4) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Website` varchar(40) NOT NULL,
  `logo` varchar(15) DEFAULT NULL,
  `loginid` int(40) NOT NULL,
  PRIMARY KEY (`compID`)
) ENGINE=MyISAM AUTO_INCREMENT=8663 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`compID`, `Name`, `Email`, `Website`, `logo`, `loginid`) VALUES
(8657, 'gonder', 'gonder@gmil.com', 'gonder.com', NULL, 2425),
(8656, 'mekele', 'mku@gmail.com', 'mekele.com', NULL, 2424),
(8650, 'harmoya UNVERSITY', 'haromaya12@gmil.com', 'jimma@gmil.com', NULL, 2407),
(8649, 'jimma UNVERSITY', 'jimma@gmil.com', 'gimma.com', NULL, 2406),
(8648, 'mesafint NGO', 'goog8le@gmail.com', 'google', NULL, 2386),
(8651, 'Chala', 'knightdom12@gmail.com', 'google@gmail.com', NULL, 2410),
(8652, 'aait', 'aaitaa@gmial.com', 'aait@gmail.com', NULL, 2418),
(8653, 'addis ababa', 'Endeshaw@gmail.com', 'www.aau.edu.et', NULL, 2419),
(8654, 'haramoya', 'haromaya@gmail.com', 'haromaya', NULL, 2422),
(8655, 'jimma', 'jimma@gmial.com', 'jimma.com', NULL, 2423),
(8658, 'hawasa', 'belema@gmil.com', 'belema.com', NULL, 2426),
(8659, 'yahoo', 'yared20@gmail.com', 'yahoo.com', NULL, 2427),
(8660, 'aait', 'aait12@gmail.com', 'aait.edut.et', NULL, 2428),
(8661, 'aastu', 'aastu@gmail.com', 'aastu.com', NULL, 2429),
(8662, 'google', 'google12@gmil.com', 'google.com', NULL, 2430);

-- --------------------------------------------------------

--
-- Table structure for table `developer`
--

DROP TABLE IF EXISTS `developer`;
CREATE TABLE IF NOT EXISTS `developer` (
  `DEVID` int(4) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(15) NOT NULL,
  `LastName` varchar(15) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `DateBirth` date NOT NULL,
  `Email` varchar(30) NOT NULL,
  `ProfilePic` varchar(15) DEFAULT NULL,
  `status` varchar(15) NOT NULL,
  `loginid` int(30) NOT NULL,
  PRIMARY KEY (`DEVID`)
) ENGINE=MyISAM AUTO_INCREMENT=5651 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `developer`
--

INSERT INTO `developer` (`DEVID`, `FirstName`, `LastName`, `Gender`, `DateBirth`, `Email`, `ProfilePic`, `status`, `loginid`) VALUES
(22, 'amanuel', 'admasu', 'male', '2016-01-04', 'ami@gmail.com', 'a.png', 'prof', 0),
(569, 'solomon', 'shiferaw', 'male', '2016-06-17', 'akdslfjaksl@gmial.com', 'sol.png', 'prof', 0),
(5632, 'abere', 'haile', 'male', '2016-06-20', 'abere1@gmail.com', 'abe.png', 'prof', 0),
(5369, 'abere', 'shiferaw', 'male', '2015-12-15', 'shiferaw@gmail.com', 'shi.png', 'prof', 0),
(1, 'Abebe', 'haile', 'female', '2016-06-20', 's.seshiferaw@gmail.com', NULL, 'pro', 2421),
(5640, 'solomon', 'shiferaw', 'M', '2016-08-20', 'shiferaw.st@gmail.com', NULL, 'professional', 2408),
(5639, 'seid ', 'miftah', 'male', '2016-06-20', 'seida12@gmail.com', NULL, 'professional', 2405),
(5642, 'susan', 'sudan', 'male', '2016-06-15', 'susan@gmail.com', NULL, 'single', 2412),
(5643, 'Daniel', 'Alemu', 'male', '2016-10-10', 'DanielAlemu@gmail.com', NULL, 'sahtgf', 2431),
(5644, 'Fruit', 'Vegitable', 'male', '1992-04-06', 'fruitis@gmail.com', NULL, 'alive', 2415),
(5645, 'chala', 'getu', 'Male', '2016-06-03', 'chala@gmail.com', NULL, 'Amateur', 2416),
(5646, 'hirut', 'bekele', 'Male', '2016-06-15', 'hirut@gmial.com', NULL, 'Amateur', 2417),
(5648, 'tsegaye', 'zeru', 'Male', '2016-06-01', 'tsegish12@gmail.com', 'x.jpg', 'Amateur', 1),
(5649, 'Daniel', 'Debebe', 'Male', '2016-06-07', 'Dani@gmail.com', NULL, '', 2),
(5650, 'hiwot', 'haile', 'Female', '2016-06-07', 'hiwaot@gmail.com', NULL, 'Amateur', 2432);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2433 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(2413, 'Daniel2', '25f9e794323b453885f5181f1b624d0b'),
(2366, 'devsd', '90c556ae5adf2d81a31cda7d58c0c333'),
(2405, 'tibe12', '2eeeefd372d30708708a788cc08c684c'),
(2432, 'hiwot12', '25f9e794323b453885f5181f1b624d0b'),
(2431, 'Daniel', '25f9e794323b453885f5181f1b624d0b'),
(2430, 'google123', '25f9e794323b453885f5181f1b624d0b'),
(2429, 'aastu', '25f9e794323b453885f5181f1b624d0b'),
(2428, 'aait12', '25f9e794323b453885f5181f1b624d0b'),
(2427, 'yahoo12', '25f9e794323b453885f5181f1b624d0b'),
(2426, 'hawasa1', '25f9e794323b453885f5181f1b624d0b'),
(2425, 'gonder12', '8b4cf0258846b23e0a8272bee22c38dd'),
(2424, 'mekele12', '25f9e794323b453885f5181f1b624d0b'),
(2423, 'jimma1', '25f9e794323b453885f5181f1b624d0b'),
(2422, 'haromoaya', '25f9e794323b453885f5181f1b624d0b'),
(2421, 'abebe', '25f9e794323b453885f5181f1b624d0b'),
(2420, 'tsege', '25f9e794323b453885f5181f1b624d0b'),
(2419, 'aau', '25f9e794323b453885f5181f1b624d0b');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) DEFAULT NULL,
  `content` longtext,
  `author` tinytext,
  `post_time` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `topic`, `content`, `author`, `post_time`) VALUES
(1, 'Good to Know', 'We declare that this written submission represents our ideas in our own words and\r\nwhere othersâ€™ ideas or words have been included. We have adequately cited and\r\nreferenced the original sources.We declare that this written submission represents our ideas in our own words and  where othersâ€™ ideas or words have been included. We have adequately cited and\r\nreferenced the original sources.', 'chala', 'Jun 6, 2016'),
(2, 'Best of Best', 'We declare that this written submission represents our ideas in our own words and where othersâ€™ ideas or words have been included. We have adequately cited and referenced the original sources.We declare that this written submission represents our ideas in our own words and where othersâ€™ ideas or words have been included. We have adequately cited and referenced the original sources.', 'chala', 'Jun 6, 2016'),
(3, 'UML Diagram improved version', 'Need more from your PDF solution? Try Foxit PhantomPDF â€“ a full featured business ready PDF solution to view, create, edit, comment, share, organize, export, OCR, secure, and sign PDF documents and forms. With Foxit PhantomPDF, you can: \r\nâ€¢Edit PDF content\r\nâ€¢Organize PDF documents\r\nâ€¢OCR of scanned documents\r\n â€¢Export to other file formats\r\nâ€¢Develop PDF forms\r\nâ€¢Protect PDF files\r\n \r\n \r\n', 'chala', 'Jun 17, 2016'),
(4, 'Microsoft bought linked in investing his  26 billion dollar', 'Regardless of their function, size or complexity, all\r\nrouter models are essentially computers and require:\r\nâ€“ Operating systems (OS)\r\nâ€“ Central processing units (CPU)\r\nâ€“ Random-access memory (RAM)\r\nâ€“ Read-only memory (ROM)', 'chala', 'Jun 17, 2016'),
(5, 'Microsoft bought linked in by 26 billion dollar', 'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\r\n;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', 'chala', 'Jun 20, 2016'),
(6, 'About world war 2', 'bhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'chala', 'Jun 20, 2016'),
(7, 'X-Hub Innovation Hub society', 'The x-hub innovation sosiety:\r\n\r\nTh', 'susi', 'Jun 20, 2016'),
(8, 'ADDIS ABABA UNIVERSITY INNOVATION COMPETITION', 'ADDIS ABABA UNIVERSITY INNOVATION COMPETITION IS GOING AND GIVE THREE STUDENT A CHANCE TO LEARN THEIR MASTERS ABROAD', 'susi', 'Jun 20, 2016'),
(9, 'X-Hub Innovation Hub society', 'The Name of the Organization shall be Youth Alliance for Leadership and Development\r\nin Africa.\r\nNo YALDA branch may change the name of the organization (please see Article XI,\r\nSection 4 for details).\r\nArticle II â€“ Head Office\r\nYALDA Head Office shall be located in Gaborone, Botswana.', 'susi', 'Jun 20, 2016'),
(10, 'Hello World', 'Welcome to the programing world! Welcome to the programing world! Welcome to the programing world! Welcome to the programing world!', 'tsegish', 'Jun 22, 2016');

-- --------------------------------------------------------

--
-- Table structure for table `professoinal_developer`
--

DROP TABLE IF EXISTS `professoinal_developer`;
CREATE TABLE IF NOT EXISTS `professoinal_developer` (
  `id` int(4) NOT NULL,
  `CV` varchar(20) NOT NULL,
  `organization` varchar(20) NOT NULL,
  `biography` varchar(1024) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `professoinal_developer`
--

INSERT INTO `professoinal_developer` (`id`, `CV`, `organization`, `biography`) VALUES
(22, 'jsadhtfjk', 'aait', 'how it is going to '),
(569, 'asdkfjh.pdf', 'AAUA', 'i am aprofessional developer\r\nworking in AAUA right know \r\ncontact me if you wanna know more'),
(999, 'yol.pdf', 'FPS', 'my name  is llllllll and i lived in llll'),
(5632, 'this is cv attached ', 'GOOGLE', 'jdhsjkfhnc fdjhasdjkfchascdf\r\nacs hjkfashfasjdfhajdfsnjasdhfjasdf\r\nasdfhjasdhfjakshdfjahsdfjhajshdfjhasdfjhachr f\r\nachjfh aac ahxf achaweuhriuwqemx cxr chxcefjhafsdx auecrh ewxauhrksrhewruahsdfjeuwrhaux cxu rehakehcurchaewxrhuaewrhxnasur'),
(5369, 'this is cv', 'SAMSUNG', 'adjfh afkaslf foasidfji faisdfj coaidjf\r\naf aisdf f asdfjfi afiaufd a\r\n faiosdf aufidoa fausd ifa dfaiodfu fuasoif asidfoua sdfiou fauaisdfkjdsjfhaui af asodfuai');

-- --------------------------------------------------------

--
-- Table structure for table `projects_and_demos`
--

DROP TABLE IF EXISTS `projects_and_demos`;
CREATE TABLE IF NOT EXISTS `projects_and_demos` (
  `ID` varchar(4) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `Date` date NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Linkofproject` varchar(200) NOT NULL,
  `ProjDevID` varchar(4) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ProjDevID` (`ProjDevID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects_and_demos`
--

INSERT INTO `projects_and_demos` (`ID`, `Title`, `Date`, `Description`, `Linkofproject`, `ProjDevID`) VALUES
('2391', 'mobile programming', '2015-09-21', 'this is mobile progrmming project done \r\nat AAIT', 'you can download the the project from the \r\nfollowing link aait.edu.et/pro/h.pdf', '1234'),
('8523', 'software engineering', '2015-07-07', 'sw', 'google.com', '8529'),
('7536', 'java game', '2016-06-30', 'hghg', 'hgj', '3214');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `email` varchar(64) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(32) NOT NULL,
  `confirmcode` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=2360 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id_user`, `name`, `email`, `username`, `password`, `confirmcode`) VALUES
(2356, 'solomon', 's.seshiferaw@gmail.com', 'solman', '54515', '54515'),
(2357, 'abere', 'knightdom@gmail.com', 'abere12', '08c49e19492409c1cebb58573f794dd3', '5ab62ee3ea1ada3013f1c6782d075c20'),
(2358, 'abubeker', 'yasinabubeker440.ay@gmial.com', 'abuke', 'f471ba1d2aac798a13a5e2f15e26c91c', 'd2ef679667c33e9614ed45393ef6c9d5'),
(2359, 'abubeker', 'shiferw.st@gmail.com', 'abul', '1a38c6e4ad4b0add4c030fa38dc79f88', 'b5f41b7039c687ce407f3c68c0af3036');

-- --------------------------------------------------------

--
-- Table structure for table `vacancy`
--

DROP TABLE IF EXISTS `vacancy`;
CREATE TABLE IF NOT EXISTS `vacancy` (
  `ID` int(4) NOT NULL,
  `compID` int(4) NOT NULL,
  `Vacancy_Type` varchar(30) NOT NULL,
  `Discription` text NOT NULL,
  `Start_Date` int(8) NOT NULL,
  `End_Date` int(8) NOT NULL,
  `Employee_needed` int(4) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `compID` (`compID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
